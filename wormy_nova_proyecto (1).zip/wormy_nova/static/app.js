const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }

const initData = tg?.initData || "";
let currentState = null;
let toastTimer = null;
const $ = (id) => document.getElementById(id);

async function api(path, method = "GET", body = null) {
  const options = { method, headers: {} };
  if (method === "GET") options.headers["X-Telegram-Init-Data"] = initData;
  else {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify({ initData, ...(body || {}) });
  }
  const response = await fetch(path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Ocurrió un error.");
  return data;
}
function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2500);
}
function render(state) {
  currentState = state;
  $("username").textContent = state.username || "Explorador";
  $("avatar").textContent = (state.username || "N").charAt(0).toUpperCase();
  $("points").textContent = Number(state.points).toLocaleString("es-EC");
  $("energy").textContent = state.energy;
  $("energyMax").textContent = state.energyMax;
  $("energyBar").style.width = `${100 * state.energy / state.energyMax}%`;
  $("power").textContent = state.power;
  $("upgradePower").textContent = state.power;
  $("upgradeCost").textContent = Number(state.upgradeCost).toLocaleString("es-EC");
  $("totalMines").textContent = `${state.totalMines} extracciones`;
  $("level").textContent = Math.max(1, Math.floor(state.totalMines / 50) + 1);
  $("mineButton").disabled = state.energy < 1;
  $("mineButton").style.opacity = state.energy < 1 ? ".6" : "1";
  $("hint").textContent = state.energy < 1 ? "Energía agotada: se recarga automáticamente." : `Cada toque obtiene ${state.power} cristal${state.power === 1 ? "" : "es"}.`;
  $("upgradeButton").disabled = state.points < state.upgradeCost;
  $("upgradeButton").style.opacity = state.points < state.upgradeCost ? ".6" : "1";
  $("missions").innerHTML = state.missions.map(m => {
    const percent = Math.min(100, 100 * m.progress / m.goal);
    let button = m.claimed
      ? '<button class="claim-button" disabled>RECLAMADA</button>'
      : m.done
        ? `<button class="claim-button ready" data-claim="${m.id}">RECLAMAR</button>`
        : '<button class="claim-button" disabled>EN CURSO</button>';
    const icon = m.id === "mine10" ? "✧" : m.id === "mine25" ? "◈" : "⬡";
    return `<article class="mission">
      <div class="mission-icon">${icon}</div>
      <div class="mission-main"><div class="mission-title">${escapeHtml(m.title)}</div>
      <div class="mission-desc">${escapeHtml(m.description)} · ${m.progress}/${m.goal}</div>
      <div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div></div>
      <div class="mission-right"><div class="reward">+${m.reward} ◈</div>${button}</div>
    </article>`;
  }).join("");
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
async function refresh() {
  try { render(await api("/api/state")); }
  catch (e) { showToast(e.message); }
}
$("mineButton").addEventListener("click", async () => {
  $("mineButton").disabled = true;
  try { render(await api("/api/mine", "POST")); }
  catch (e) { showToast(e.message); }
  finally { if (currentState) $("mineButton").disabled = currentState.energy < 1; }
});
$("upgradeButton").addEventListener("click", async () => {
  try { render(await api("/api/upgrade", "POST")); showToast("¡Taladro mejorado!"); }
  catch (e) { showToast(e.message); }
});
$("missions").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-claim]");
  if (!button) return;
  button.disabled = true;
  try { render(await api("/api/claim", "POST", { missionId: button.dataset.claim })); showToast("¡Recompensa añadida!"); }
  catch (e) { showToast(e.message); }
});
$("navMissions").addEventListener("click", () => $("missions").scrollIntoView({ behavior: "smooth", block: "start" }));
$("navUpgrade").addEventListener("click", () => $("upgradeButton").scrollIntoView({ behavior: "smooth", block: "center" }));

refresh();
// Refreshing state keeps energy regeneration visible while the app is open.
setInterval(refresh, 15000);
