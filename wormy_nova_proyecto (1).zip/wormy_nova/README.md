# Wormy Nova — Telegram Bot + Mini App

Juego de minería **virtual** con cristales, energía, mejoras y misiones diarias. Los puntos no tienen valor monetario y esta plantilla no incluye pagos ni retiros.

## Requisitos

- Python 3.10 o superior (se recomienda Python 3.11/3.12).
- Una cuenta de Telegram.
- Para probar solo la web local: no necesitas token todavía.
- Para usarlo en Telegram: crea un bot con [@BotFather](https://t.me/BotFather).
- Para producción, la Mini App debe publicarse con HTTPS.

## 1. Preparar el proyecto en Windows

Extrae el ZIP y abre la carpeta `wormy_nova` en Visual Studio Code.

Abre Terminal > Nueva terminal y ejecuta:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Si PowerShell bloquea la activación, puedes ejecutar directamente:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 2. Ejecutar la vista previa local

En PowerShell, configura el modo de prueba y arranca el servidor:

```powershell
$env:DEV_MODE="true"
$env:BOT_TOKEN=""
$env:WEBAPP_URL=""
uvicorn main:app --reload
```

Abre `http://127.0.0.1:8000` en el navegador. La vista previa usa un jugador de demostración; no es una sesión real de Telegram.

## 3. Crear el bot de Telegram

1. Abre [@BotFather](https://t.me/BotFather) en Telegram.
2. Envía `/newbot`.
3. Elige el nombre y el username del bot; el username debe terminar en `bot`.
4. Copia el token que te entrega BotFather y guárdalo en privado.
5. No compartas el token ni lo subas a GitHub.

Para arrancar el bot y el servidor localmente:

```powershell
$env:BOT_TOKEN="PEGA_AQUI_TU_TOKEN"
$env:DEV_MODE="true"
$env:WEBAPP_URL=""
uvicorn main:app --reload
```

Con `WEBAPP_URL` vacío, `/start` responde, pero todavía no abrirá la Mini App desde Telegram.

## 4. Publicar la Mini App

Telegram requiere una URL HTTPS pública para abrir la Mini App desde un bot normal.

1. Publica esta aplicación FastAPI en un servicio de hosting que admita Python y HTTPS.
2. Configura `BOT_TOKEN` en las variables de entorno del hosting.
3. Configura `WEBAPP_URL` con la URL HTTPS pública exacta de la aplicación.
4. Configura `DEV_MODE=false` en producción.
5. Reinicia el servicio.
6. En Telegram, abre BotFather y usa `/setmenubutton`; elige tu bot, escribe `Abrir juego` y pega la URL HTTPS.
7. Envía `/start` a tu bot y pulsa **Abrir Wormy Nova**.

No publiques el servidor con `DEV_MODE=true`: en ese modo se permite un jugador de demostración para probar la interfaz sin Telegram.

## 5. Comandos del bot

- `/start` — bienvenida y botón para abrir el juego.
- `/help` — muestra la ayuda.

## 6. Reglas iniciales del juego

- Energía máxima: 100.
- Regeneración: 1 unidad cada 5 segundos.
- Cada toque consume 1 energía.
- Los cristales ganados por toque equivalen a la potencia del taladro.
- La primera mejora cuesta 100 cristales y cada mejora posterior cuesta `100 × potencia actual`.
- Misiones diarias: 10 extracciones, 25 extracciones y comprar una mejora.
- Las recompensas de misión se pueden reclamar una sola vez por día UTC.

## Estructura

```text
wormy_nova/
├── main.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── static/
    ├── index.html
    ├── style.css
    └── app.js
```

## Seguridad y siguientes pasos

- El servidor valida `Telegram.WebApp.initData` con el token del bot cuando `DEV_MODE=false`.
- Los puntos y las misiones se actualizan en el servidor, no desde el navegador.
- SQLite es suficiente para una demo; para una comunidad grande, migra a PostgreSQL.
- Añade límites de frecuencia, copias de seguridad, registros y monitorización antes de abrirlo al público.
- No uses los puntos como promesa de ingresos. No se incluye criptomoneda, pagos ni retiros.
