import asyncio
import hashlib
import hmac
import json
import os
import sqlite3
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl

from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DB_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "wormy_nova.db"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
DEV_MODE = os.getenv("DEV_MODE", "true").lower() == "true"

ENERGY_MAX = 100
ENERGY_REGEN_SECONDS = 5
START_POINTS = 0
START_ENERGY = 100

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT NOT NULL DEFAULT '',
                points INTEGER NOT NULL DEFAULT 0,
                energy INTEGER NOT NULL DEFAULT 100,
                energy_updated REAL NOT NULL DEFAULT 0,
                power INTEGER NOT NULL DEFAULT 1,
                total_mines INTEGER NOT NULL DEFAULT 0,
                mines_today INTEGER NOT NULL DEFAULT 0,
                upgrades_today INTEGER NOT NULL DEFAULT 0,
                day_key TEXT NOT NULL DEFAULT ''
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS mission_claims (
                user_id INTEGER NOT NULL,
                mission_id TEXT NOT NULL,
                day_key TEXT NOT NULL,
                PRIMARY KEY (user_id, mission_id, day_key)
            )
        """)

def today_key():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def validate_init_data(init_data: str):
    """Validate Telegram Mini App initData using the official HMAC procedure."""
    if not BOT_TOKEN or not init_data:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash", None)
        pairs.pop("signature", None)
        if not received_hash:
            return None
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated_hash = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated_hash, received_hash):
            return None
        auth_date = int(pairs.get("auth_date", "0"))
        if time.time() - auth_date > 86400 or auth_date > time.time() + 60:
            return None
        user_raw = pairs.get("user")
        if not user_raw:
            return None
        user = json.loads(user_raw)
        user_id = int(user["id"])
        username = str(user.get("username") or user.get("first_name") or "Jugador")[:80]
        return user_id, username
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None

def get_identity(init_data: str):
    identity = validate_init_data(init_data)
    if identity:
        return identity
    if DEV_MODE:
        # Local preview only. Disable DEV_MODE before public deployment.
        return 100000001, "JugadorDemo"
    raise HTTPException(status_code=401, detail="Sesión de Telegram inválida. Abre el juego desde el bot.")

def ensure_user(user_id: int, username: str):
    now = time.time()
    day = today_key()
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            con.execute(
                "INSERT INTO users(user_id, username, points, energy, energy_updated, power, day_key) VALUES(?,?,?,?,?,?,?)",
                (user_id, username, START_POINTS, START_ENERGY, now, 1, day)
            )
        else:
            # Refill energy gradually, capped at ENERGY_MAX.
            elapsed = max(0, int(now - float(row["energy_updated"])))
            regenerated = elapsed // ENERGY_REGEN_SECONDS
            energy = min(ENERGY_MAX, int(row["energy"]) + regenerated)
            updated_at = float(row["energy_updated"]) + regenerated * ENERGY_REGEN_SECONDS
            if energy >= ENERGY_MAX:
                updated_at = now
            mines_today = int(row["mines_today"])
            upgrades_today = int(row["upgrades_today"])
            day_key = row["day_key"]
            if day_key != day:
                mines_today = 0
                upgrades_today = 0
                day_key = day
            con.execute(
                "UPDATE users SET username=?, energy=?, energy_updated=?, mines_today=?, upgrades_today=?, day_key=? WHERE user_id=?",
                (username, energy, updated_at, mines_today, upgrades_today, day_key, user_id)
            )

def state_for(user_id: int):
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        claims = {r["mission_id"] for r in con.execute(
            "SELECT mission_id FROM mission_claims WHERE user_id=? AND day_key=?",
            (user_id, today_key())
        ).fetchall()}
    if not row:
        raise HTTPException(status_code=500, detail="No se pudo cargar el jugador.")
    mines_today = int(row["mines_today"])
    upgrades_today = int(row["upgrades_today"])
    missions = [
        {"id": "mine10", "title": "Recolector novato", "description": "Extrae 10 veces hoy", "progress": min(mines_today, 10), "goal": 10, "reward": 50, "claimed": "mine10" in claims, "done": mines_today >= 10},
        {"id": "mine25", "title": "Lluvia de cristales", "description": "Extrae 25 veces hoy", "progress": min(mines_today, 25), "goal": 25, "reward": 120, "claimed": "mine25" in claims, "done": mines_today >= 25},
        {"id": "upgrade1", "title": "Ingeniero espacial", "description": "Compra una mejora hoy", "progress": min(upgrades_today, 1), "goal": 1, "reward": 80, "claimed": "upgrade1" in claims, "done": upgrades_today >= 1},
    ]
    return {
        "username": row["username"],
        "points": int(row["points"]),
        "energy": int(row["energy"]),
        "energyMax": ENERGY_MAX,
        "power": int(row["power"]),
        "upgradeCost": 100 * int(row["power"]),
        "totalMines": int(row["total_mines"]),
        "minesToday": mines_today,
        "missions": missions,
    }

class InitPayload(BaseModel):
    initData: str = ""

class ClaimPayload(BaseModel):
    initData: str = ""
    missionId: str

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    bot_task = None
    if BOT_TOKEN:
        bot_task = asyncio.create_task(run_bot())
    yield
    if bot_task:
        bot_task.cancel()
        try:
            await bot_task
        except asyncio.CancelledError:
            pass

app = FastAPI(title="Wormy Nova", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
async def home():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/api/state")
async def api_state(x_telegram_init_data: str = Header(default="", alias="X-Telegram-Init-Data")):
    user_id, username = get_identity(x_telegram_init_data)
    ensure_user(user_id, username)
    return state_for(user_id)

@app.post("/api/mine")
async def api_mine(payload: InitPayload):
    user_id, username = get_identity(payload.initData)
    ensure_user(user_id, username)
    with db() as con:
        row = con.execute("SELECT energy, points, power FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row["energy"] < 1:
            raise HTTPException(status_code=400, detail="Te has quedado sin energía. Espera un poco para recargar.")
        earned = int(row["power"])
        con.execute("""
            UPDATE users
            SET energy=energy-1, points=points+?, total_mines=total_mines+1,
                mines_today=mines_today+1, energy_updated=?
            WHERE user_id=?
        """, (earned, time.time(), user_id))
    return state_for(user_id)

@app.post("/api/upgrade")
async def api_upgrade(payload: InitPayload):
    user_id, username = get_identity(payload.initData)
    ensure_user(user_id, username)
    with db() as con:
        row = con.execute("SELECT points, power FROM users WHERE user_id=?", (user_id,)).fetchone()
        cost = 100 * int(row["power"])
        if int(row["points"]) < cost:
            raise HTTPException(status_code=400, detail=f"Necesitas {cost} cristales para mejorar.")
        con.execute(
            "UPDATE users SET points=points-?, power=power+1, upgrades_today=upgrades_today+1 WHERE user_id=?",
            (cost, user_id)
        )
    return state_for(user_id)

@app.post("/api/claim")
async def api_claim(payload: ClaimPayload):
    user_id, username = get_identity(payload.initData)
    ensure_user(user_id, username)
    rewards = {"mine10": (10, 50), "mine25": (25, 120), "upgrade1": (1, 80)}
    if payload.missionId not in rewards:
        raise HTTPException(status_code=400, detail="Misión desconocida.")
    goal, reward = rewards[payload.missionId]
    day = today_key()
    with db() as con:
        row = con.execute("SELECT mines_today, upgrades_today FROM users WHERE user_id=?", (user_id,)).fetchone()
        progress = int(row["upgrades_today"] if payload.missionId == "upgrade1" else row["mines_today"])
        if progress < goal:
            raise HTTPException(status_code=400, detail="Todavía no has completado esta misión.")
        exists = con.execute(
            "SELECT 1 FROM mission_claims WHERE user_id=? AND mission_id=? AND day_key=?",
            (user_id, payload.missionId, day)
        ).fetchone()
        if exists:
            raise HTTPException(status_code=400, detail="Ya reclamaste esta recompensa hoy.")
        con.execute(
            "INSERT INTO mission_claims(user_id, mission_id, day_key) VALUES(?,?,?)",
            (user_id, payload.missionId, day)
        )
        con.execute("UPDATE users SET points=points+? WHERE user_id=?", (reward, user_id))
    return state_for(user_id)

dp = Dispatcher()

if BOT_TOKEN:
    @dp.message(Command("start"))
    async def start_handler(message: Message):
        name = message.from_user.first_name if message.from_user else "explorador"
        text = (
            f"🚀 ¡Bienvenido a Wormy Nova, {name}!\n\n"
            "Explora una estación espacial, extrae cristales, mejora tu equipo y completa misiones. "
            "Los cristales son puntos virtuales del juego y no tienen valor monetario."
        )
        if WEBAPP_URL.startswith("https://"):
            keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🌌 Abrir Wormy Nova", web_app=WebAppInfo(url=WEBAPP_URL))
            ]])
            await message.answer(text, reply_markup=keyboard)
        else:
            await message.answer(text + "\n\nEl juego web todavía no está configurado. Configura WEBAPP_URL con tu URL HTTPS.")

    @dp.message(Command("help"))
    async def help_handler(message: Message):
        await message.answer(
            "Comandos disponibles:\n/start — abrir Wormy Nova\n/help — ayuda\n\n"
            "En el juego puedes extraer cristales, comprar mejoras y reclamar misiones."
        )

async def run_bot():
    bot = Bot(token=BOT_TOKEN)
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()
